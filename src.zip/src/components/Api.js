// import axios from "axios";
// export const sendEncryptedData = async (encryptedData) => {
//   try {
//     const response = await axios.post("https//someapi.com", { encryptedData });
//     return response.data;
//   } catch (error) {
//     console.error("error in sending encrypted data", error);
//     throw error;
//   }
// };
